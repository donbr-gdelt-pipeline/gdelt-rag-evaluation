# Evaluation Evidence Folder
Place RAGAS outputs here.